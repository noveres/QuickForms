export const environment = {
  production: true,
  apiUrl: '/api', // 生產環境 API URL，使用相對路徑
};
