export const environment = {
  production: false,
  apiUrl: 'http://localhost:8585/api', // 開發環境 API URL
};
